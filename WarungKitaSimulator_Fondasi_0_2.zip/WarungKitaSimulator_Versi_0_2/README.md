# Warung Kita Simulator - Fondasi Versi 0.2

Proyek awal Godot 4.3 untuk game Android offline.

## Isi saat ini
- Scene 3D dasar warung tradisional dengan bagian depan terbuka.
- Interior awal: meja kasir, rak, dan kemasan dagangan berwarna.
- Lingkungan sederhana berupa tanah, jalan, dan rumah tetangga.
- Karakter orang pertama dengan joystick virtual, geser kamera, tombol lari, dan tombol interaksi.
- Menu utama, pengaturan dasar (informasi), dan Tentang Game.
- Kredit: Dikembangkan oleh Aditia Hermawan.
- Renderer Compatibility untuk target Android yang lebih luas.

## Batasan tahap ini
Ini masih fondasi teknis, bukan game final. Barang belum memiliki model/tekstur produk asli, tombol interaksi belum menjalankan transaksi, belum ada pelanggan, pemasok, ekonomi, atau penyimpanan permainan. Splash screen 5 detik dan ikon final juga belum disiapkan.

## Cara membuka
Buka folder ini sebagai project di Godot 4.3. Main scene: `res://scenes/main.tscn`.

## Catatan Android
Periksa preset ekspor Android di editor Godot sebelum ekspor. Workflow GitHub lama tidak otomatis menjamin proyek ini bebas error. Jalankan tes scene dan APK di perangkat sebelum dianggap selesai.
